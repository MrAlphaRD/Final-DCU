<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Estudiantes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link href="https://cdn.datatables.net/v/bs5/dt-1.13.4/datatables.min.css" rel="stylesheet"/>
</head>
<body>
    <div class="container">
        <div class="row p-2">
            <div class="col-3">
                <form action="acciones/insertar.php" method="POST" enctype="multipart/form-data">
                    <h3 class="text-center">REGISTRA UN ESTUDIANTE</h3>
                    <label>Nombre</label>
                    <input class='form-control' type="text" name="nombre">
                    <label>Apellido</label>
                    <input class='form-control' type="text" name="apellido">
                    <label>Correo</label>
                    <input class='form-control' type="email" name="correo">
                    <label>Telefono</label>
                    <input class='form-control' type="tel" name="telefono">
                    <label>Foto</label>
                    <input class='form-control' type="file" name="foto">
                    <button class="btn btn-primary mt-2" type="submit">Registrar</button>
                </form>
            </div>
            <div class="col-9">
                Lista de alumnos
                <table class="table" id="mitabla">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nombre</th>
                            <th>Apellido</th>
                            <th>Correo</th>
                            <th>Telefono</th>
                            <th>Foto</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            include "config/bd.php";
                            $query=listar();
                            $enumeracion=0;
                            while($datos=mysqli_fetch_assoc($query)){
                                $enumeracion++;
                                $id=$datos['id_estudiantes'];
                                $nombre=$datos['nombre'];
                                $apellido=$datos['apellido'];
                                $correo=$datos['correo'];
                                $telefono=$datos['telefono'];
                                $foto=$datos['foto'];
                        
                        
                        ?>
                        <tr>
                            <td><?= $enumeracion?></td>
                            <td><?= $nombre?></td>
                            <td><?= $apellido?></td>
                            <td><?= $correo?></td>
                            <td><?= $telefono?></td>
                            <td><img style="max-height:50px;" src="data:image/jpg;base64,<?= base64_encode($foto)?>"></td>
                            <td>
                                <a class="btn btn-info" href="ver.php?id=<?=$id?>">Ver</a>
                                <a class="btn btn-warning" href="editar.php?id=<?=$id?>">Actualizar</a>
                                <a class="btn btn-danger" href="acciones/eliminar.php?id_estudiantes=<?=$id?>">Eliminar</a>
                            </td>
                        </tr>

                        <?php
                            }
                        ?>
                    </tbody>
                </table>      
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js" integrity="sha256-oP6HI9z1XaZNBrJURtCoUT5SUnxFr8s3BzRl+cbzUq8=" crossorigin="anonymous"></script>
    <script src="https://cdn.datatables.net/v/bs5/dt-1.13.4/datatables.min.js"></script>
    <script>
        $(document).ready( function () {
            $('#mitabla').DataTable( {
            language: {
                url: 'https://cdn.datatables.net/plug-ins/1.13.4/i18n/es-ES.json'
            }
        });
        });

    </script>

</body>
</html>