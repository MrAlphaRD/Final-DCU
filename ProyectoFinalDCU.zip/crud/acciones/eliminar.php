<?php

$id=$_GET['id_estudiantes'];
include "../config/bd.php";
$query=eliminar($id);

header('location:../index.php');