<?php

$id=$_POST['id'];
$nombre=$_POST['nombre'];
$apellido=$_POST['apellido'];
$correo=$_POST['correo'];
$telefono=$_POST['telefono'];
$foto=$_FILES['foto'];
include "../config/bd.php";

if($foto['size']==0){
    $query=actualizarSinFoto($id,$nombre,$apellido,$correo,$telefono);
}else{
    $foto=addslashes(file_get_contents($foto['tmp_name']));
    $query=actualizar($id,$nombre,$apellido,$correo,$telefono,$foto);
}

header("location:../editar.php?id=$id");