<?php
include "../config/bd.php";

$nombre=$_POST['nombre'];
$apellido=$_POST['apellido'];
$correo=$_POST['correo'];
$telefono=$_POST['telefono'];
$foto=$_FILES['foto'];

$foto=addslashes(file_get_contents($foto['tmp_name']));

$query=insertar($nombre,$apellido,$correo,$telefono,$foto);

header('location:../index.php');