<?php

function conexion(){
    $conexion=mysqli_connect('localhost','root','','registro_estudiantes');
    return $conexion;
}
function listar(){
    $sql="SELECT * FROM registros";
    $query=mysqli_query(conexion(),$sql);
    return $query;
}
function insertar($nombre,$apellido,$correo,$telefono,$foto){
    $sql="INSERT INTO registros(nombre,apellido,correo,telefono,foto) VALUES ('$nombre','$apellido','$correo','$telefono','$foto')";
    $query=mysqli_query(conexion(),$sql);
    return $query;
}
function eliminar($id){
    $sql="DELETE from registros WHERE id_estudiantes=$id";
    $query=mysqli_query(conexion(),$sql);
    return $query;
}
function ListarunAlumno($id){
    $sql="SELECT * from registros WHERE id_estudiantes=$id";
    $query=mysqli_query(conexion(),$sql);
    return mysqli_fetch_assoc($query);
}
function actualizar($id,$nombre,$apellido,$correo,$telefono,$foto){
    $sql="UPDATE registros set nombre='$nombre',apellido='$apellido',correo='$correo',telefono='$telefono',foto='$foto' WHERE id_estudiantes=$id";
    $query=mysqli_query(conexion(),$sql);
    return $query;
}
function actualizarSinFoto($id,$nombre,$apellido,$correo,$telefono){
    $sql="UPDATE registros set nombre='$nombre',apellido='$apellido',correo='$correo',telefono='$telefono' WHERE id_estudiantes=$id";
    $query=mysqli_query(conexion(),$sql);
    return $query;
}